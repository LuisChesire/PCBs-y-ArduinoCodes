<?php
	$server = "localhost";
	$user = "root";
	$passUser = "ConejoKoala";
	$database = "evos";
	$conexion = mysqli_connect($server, $user, $passUser, $database);
	
	if(!$conexion){
		echo "Error al conectar con la base de datos";
	}
	else{
		mysqli_query($conexion, "SET NAMES 'utf8'");
	}
?>