<?php
    include("configBD.php");   
    session_start();
    $var= $_POST['value'];
    //echo $var;
    set_time_limit(100);
    //exec('java -jar dist/BlindRsa.jar '.$var.' 2>&1', $output);
    //$data = implode(" ", $output);
    //echo $data;
    $sql = "SELECT nombre, ap, am, idPartido FROM candidatos";
    $res = mysqli_query($conexion, $sql);
    $cuenta = mysqli_fetch_all($res,MYSQLI_ASSOC);
    //Asociacion de arreglos
    $nombresA=array_column($cuenta, 'nombre');
    $apA=array_column($cuenta,'ap');
    $amA=array_column($cuenta,'am');
        for ($i = 0; $i <count($cuenta); $i++) {
            $candNom[$i]=$nombresA[$i].' '.$apA[$i].' '.$amA[$i].' ';
            //echo " Candidato ".($i+1).": ".$candNom[$i]." Partido: ".$part[$i];
        }   
    $dataName=implode(" ",$candNom); 
	$idPartido=0; 
    if(strcmp($var,"Homer Jay Simpson ")== 0){
    	$idPartido=1;
    	}
   	if(strcmp($var,"Krusty The Clown ")== 0){
    	$idPartido=2;
   		}
   	if(strcmp($var,"Ned Flanders  ")==0){
    	$idPartido=3;
   		}	
    //echo '<br>Partido: '.$idPartido;
    $numbers = rand(0,200);
   	$sql = "INSERT INTO voto (idVoto, idCandidato ) VALUES ('$numbers', '$idPartido');";
   	if (mysqli_query($conexion, $sql)) {
    echo "Voto folio #".$numbers." almacenado correctamente.";
	} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
	}   
?>