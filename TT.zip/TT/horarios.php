<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>SIAEE | Panel de administracion</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- Toastr style -->
    <link href="css/plugins/toastr/toastr.min.css" rel="stylesheet">

    <!-- Gritter -->
    <link href="js/plugins/gritter/jquery.gritter.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body>
    <div id="wrapper">
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav metismenu" id="side-menu">
                    <li class="nav-header">
                        <div align="center">
                            <img src="escomL.png" border="0" width="80%" height="80%">   
                        </div>
                        <div class="logo-element">
                            SIAEE
                        </div>
                    </li>

                     <li class="active">
                        <a href=""><i class="fa fa-th-large"></i> <span class="nav-label">Panel de administracion</span> <span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level collapse">
                            <li class="active"><a href="usuarios.php">Administrar usuarios</a></li>
                            <li><a href="horarios.php">Administrar horarios</a></li>
                            <li><a href="grafica.php">Generar grafica</a></li>
                        </ul>
                    </li>
                   <!--Aqui poner mas opciones para el menu-->

                </ul>
            </div>
        </nav>

        <div id="page-wrapper" class="gray-bg dashbard-1">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a> 
        </div>
            <ul class="nav navbar-top-links navbar-right">
                <li>
                    <a href="cerrar.php">
                        <i class="fa fa-sign-out"></i> Log out
                    </a>
                </li>
                
            </ul>
        </nav>
        </div>

           <!--Aqui poner las ubicaciones-->

        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-10">
                <h2>SIAEE</h2>
                <ol class="breadcrumb">
                    <li>
                        <a href="PanelAdmin.php">SIAEE</a>
                    </li>
                    <li>
                        <a>Panel de admnistración</a>
                    </li>
                    <li class="active">
                        <strong>Administrar usuarios</strong>
                    </li>
                </ol>
            </div>
        </div>

        <div class="wrapper wrapper-content  animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                        <div class="ibox-content">
                            <h2>Administración de horarios</h2>
                            <div>
                            <ul class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#tab-1"><i class="fa fa-hastag"></i>ID</a></li>
                                <li class="active"><a data-toggle="tab" href="#tab-1"><i class="fa fa-calendar"></i> Fecha &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a></li>
                                <li class="active"><a data-toggle="tab" href="#tab-1"><i class="fa fa-clock-o"></i>Hora de inicio&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a></li>
                                <li class="active"><a data-toggle="tab" href="#tab-1"><i class="fa fa-clock-o"></i>Hora de termino &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</a></li>
                                   <li class="active"><a data-toggle="tab" href="#tab-1"><i class="fa fa-pencil"></i>Modificar</a></li>
                                    <li class="active"><a data-toggle="tab" href="#tab-1"><i class="fa fa-ban"></i>Eliminar</a></li>
                            </ul>

                            <div class="tab-content">
                            <form id="form1" name="form1" method="post"  >
                                <div id="tab-1" class="tab-pane active">
                                    <div class="full-height-scroll">
                                        <div class="table-responsive" align="center">
                                            <table class="table table-striped table-hover">
                                                <tbody>
                                                <tr>
                                                    <td width="70">1</td>
                                                    <!--<a data-toggle="tab" href="#contact-1" class="client-link"><?php echo $candNom[0];?></a>-->
                                                    <td width="230">
                                                        <input type="date" name="fecha">
                                                    </td>
                                                    <td width="200"><input type="time"></td>
                                                    <td width="200"><input type="time"></td>
                                                    <td class="i-checks" width="130"><input type="checkbox" name="modificar" onChange="fHabilitar(); return false;"></td>
                                                    <td class="i-checks"><input type="checkbox" name="eliminar" onChange="fHabilitar(); return false;"></td>

                                                </tr>
                                                <tr>
                                                    <td width="70">2</td>
                                                    <!--<a data-toggle="tab" href="#contact-1" class="client-link"><?php echo $candNom[0];?></a>-->
                                                    <td width="230">
                                                        <input type="date" name="fecha">
                                                    </td>
                                                    <td width="200"><input type="time"></td>
                                                    <td width="200"><input type="time"></td>
                                                    <td class="i-checks" width="130"><input type="checkbox" name="modificar" onChange="fHabilitar(); return false;"></td>
                                                    <td class="i-checks"><input type="checkbox" name="eliminar" onChange="fHabilitar(); return false;"></td>
                                                </tr>
                                                <tr>
                                                    <td width="70">3</td>
                                                    <!--<a data-toggle="tab" href="#contact-1" class="client-link"><?php echo $candNom[0];?></a>-->
                                                    <td width="230">
                                                        <input type="date" name="fecha">
                                                    </td>
                                                    <td width="200"><input type="time"></td>
                                                    <td width="200"><input type="time"></td>
                                                    <td class="i-checks" width="130"><input type="checkbox" name="modificar" onChange="fHabilitar(); return false;"></td>
                                                    <td class="i-checks"><input type="checkbox" name="eliminar" onChange="fHabilitar(); return false;"></td>
                                                </tr>
                                    
                                                </tbody>
                                            </table>
                                            <input type="button" class="btn btn-sm btn-primary pull-right m-t-n-xs"  name="botonGuardar" id="botonGuardar" value="Aceptar" onClick="validar(); return false;" disabled>
                                            <!--<input type="submit" class="btn btn-sm btn-primary pull-right m-t-n-xs" name="botonFirmar" id="botonFirmar" formmethod="post" formaction="exito.php" value="Sign" disabled >-->
                                        </div>
                                    </div>
                                </div>
                            </form>
                            </div>
        </div>
        </div>
        </div>
<script language="javascript" type="text/javascript" src="scripts/confirmar.js"></script>

    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>

    <!--<script>
        $(document).ready(function(){
            $('.contact-box').each(function() {
                animationHover(this, 'pulse');
            });
        });
    </script>-->

</body>

</html>