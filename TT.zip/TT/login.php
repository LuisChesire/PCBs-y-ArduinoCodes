<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>SIAEE | Log in</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="gray-bg">

    <div class="loginColumns animated fadeInDown" align="center">
        <div class="row" align="center">
                
            <img align="center" src="Logo.png" width="800" height="250">
            <!--<h1 class="font-bold" align="center" >Welcome to e-VOS </h1>-->
            <div class="col-md-6">
                <BR>
                <BR>
                <BR>
                
                <!--<h1 class="font-bol d" align="center" >Welcome to e-VOS </h1> action="validar.php"-->
 
                <div class="ibox-content">
                   <form class="m-t" role="form" method="post">
                        <div class="form-group">
                            <input  class="form-control" placeholder="User" type="text" id="cu" name="cu" required="">
                        </div>
                        <div class="form-group">
                            <input class="form-control" placeholder="ID" type="password" id="pass" name="pass" required="">
                        </div>
                        <button class="btn btn-primary block full-width m-b" formaction="PanelAdmin.php" type="submit">Log in</button>
                </div>
                
            </div>
            
            <!--<h2 class="font-bold" align="center" >Expo ESCOM </h2>-->
            
            <br>
            <br>
            <!--<embed src="e-voting.mp4" width="370" height="270">-->
            
        </div>
        </div>
    </div>

</body>

</html>
