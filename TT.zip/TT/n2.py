from datetime import datetime
import json 
import serial
import time
puerto = "COM6"
ser = serial.Serial(puerto,9600, timeout = 10)
time.sleep(2)

while True:
	try:
		if ser.inWaiting()>0:
			data = {}
			data['graf']=[]
			while True:
				now = datetime.now()
				rx = ser.readline()
				Data = rx.decode(encoding = "utf-8")
				Temp = Data.rstrip('\r\n')
				Dato = float(Temp)
				Fecha = datetime.timestamp(now) 
				temp1 = str(Fecha)
				temp2 = temp1[0:10]+"000"
				Fecha = int(temp2)
				data['graf'].append([Fecha,Dato])
				with open('data.json', 'w') as file:
					json.dump(data, file, indent = 4)
	except KeyboardInterrupt:
			ser.close()
			print ('\n Program Stopped')
			break