// JavaScript Document
function confirmarEnvio(nomForm){
	if(confirm('¿Desea realizar la operación?')){
		var formulario = nomForm;
		document.forms[formulario].submit()
	}
}

function deshabilita(form)
{
    if ((form1.a.value != ""))
    { form.v.disabled = false; }

    else {
    form.v.disabled = true; }
}

function cancelarOp(pag){
	var pagina = pag;
	if(confirm('¿Desea cancelar la operación?')){
		window.location.assign(pagina)
	}
}