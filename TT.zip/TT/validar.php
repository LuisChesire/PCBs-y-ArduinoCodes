<?php

//obtenemos los valores del formulario
	$username=$_POST['cu'];
	$pass=$_POST['pass'];

//prevenimos sql injevtion
	//$username = stripcslashes($username);
	//$pass = stripcslashes($pass); 
	//$username = mysql_real_escape_string($username);
	//$pass = mysql_real_escape_string($pass);

session_start();
	require("configBD.php");

	$sql = mysqli_query($conexion,"SELECT * FROM votante WHERE CURP ='$username'");
	if($f=mysqli_fetch_assoc($sql)){
		if($pass==$f['FolioElector']){
			$_SESSION['CURP']= $username;

			header("Location: Principal.php");
		}else{
			echo '<script>alert("CONTRASEÑA INCORRECTA")</script> ';
		
			echo "<script>location.href='login.php'</script>";
		}
	}else{
		
		echo '<script>alert("ESTE USUARIO NO EXISTE, PORFAVOR REGISTRESE PARA PODER INGRESAR")</script> ';
		
		echo "<script>location.href='login.php'</script>";	

	}

?>